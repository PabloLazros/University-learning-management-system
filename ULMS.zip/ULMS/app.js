// Some libraries required
const express = require('express');
const sqlite3 = require('sqlite3');
const bodyParser = require('body-parser');
const session = require('express-session');
const bcrypt = require('bcrypt');
const multer = require('multer');
const path = require('path');

const app = express();

// App port number to run on
const port = 3000;

// set app route & structure
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use('/images', express.static(__dirname + '/images'));
app.use('/project_pictures', express.static('images/project_pictures'));

// SQLite database
const db = new sqlite3.Database('./ULMS.db');

app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: 'your-secret-key', resave: true, saveUninitialized: true }));

// Middleware to check if the user is logged in
const requireLogin = (req, res, next) => {
  if (!req.session.user) {
    console.log('User not logged in. Redirecting to /login');
    res.redirect('/login');
  } else {
    console.log('User is logged in. Proceeding to the next middleware');
    next();
  }
};

// Set up multer storage
const storage = multer.diskStorage({
  destination: './images/project_pictures/', // Destination for storing uploaded files
  filename: function (req, file, cb) {
    cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Middleware to check if the user is an admin
const isAdmin = (req, res, next) => {
  if (req.session.user && req.session.user.role === 'admin') {
    next();
  } else {
    res.status(403).send('Forbidden');
  }
};

// Admin route
app.get('/admin', isAdmin, (req, res) => {
  const user = req.session.user;
  const searchResults = [];
  // Only admin can access this route
  res.render('admin',{ user, searchResults });
});

// Handle Search Users in Admin Page
app.post('/admin', isAdmin, (req, res) => {
  const { searchQuery } = req.body;
  const user = req.session.user;

  // Perform a search based on the searchQuery (you can customize this query)
  db.all('SELECT * FROM users WHERE username LIKE ?', [`%${searchQuery}%`], (err, searchResults) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Render the search results
    res.render('admin', { user, searchResults });
  });
});

// Logout & kill session 
app.get('/logout', (req, res) => {
  // Destroy the session to log the user out
  req.session.destroy(err => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Redirect to the login page after logout
    res.redirect('/login');
  });
});

// Redirect / to /login if not logged in, and /home if logged in
app.get('/', (req, res) => {
  if (req.session.user) {
    console.log('User is logged in. Redirecting to /home');
    res.redirect('/home');
  } else {
    console.log('User is not logged in. Redirecting to /login');
    res.redirect('/login');
  }
});

// Login Page
app.get('/login', (req, res) => {
  console.log('Rendering login.ejs');
  res.render('login', { error: null }); // Pass an empty error initially
});

// Handle Login
app.post('/login', (req, res) => {
  const { username, password } = req.body;

  // Check if the provided username exists in the database
  db.get('SELECT * FROM users WHERE username = ?', [username], (err, user) => {
    if (err) {
      console.error('Error retrieving user:', err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    if (!user) {
      // Username not found, redirect to login with an error message
      console.log('User not found for username:', username);
      res.render('login', { error: 'Invalid Credentials' });
      return;
    }

    // Compare the provided password with the stored hashed password
    bcrypt.compare(password, user.password, (bcryptErr, passwordMatch) => {
      if (bcryptErr) {
        console.error('Bcrypt error:', bcryptErr.message);
        res.status(500).send('Internal Server Error');
        return;
      }

      if (passwordMatch) {
        req.session.user = user; // Set user session
        console.log('Login successful for user:', username);
        res.redirect('/home');
      } else {
        // Incorrect password, show login with an error message
        console.log('Incorrect password for user:', username);
        res.render('login', { error: 'Invalid Credentials' });
      }
    });
  });
});


// Add a route for the projects page
app.get('/projects', requireLogin, (req, res) => {
  // Retrieve recent projects
  db.all('SELECT * FROM projects ORDER BY created_at DESC LIMIT 10', (err, recentProjects) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Render the projects page with the list of recent projects
    res.render('projects', { user: req.session.user, recentProjects });
  });
});

// Home Page
app.get('/home', requireLogin, (req, res) => {
    // Retrieve posts for all users
    db.all('SELECT posts.*, users.username, users.profile_picture FROM posts JOIN users ON posts.user_id = users.id ORDER BY created_at DESC', (err, posts) => {
      if (err) {
        console.error(err.message);
        res.status(500).send('Internal Server Error');
        return;
      }

    
  
      // Render the home page with the list of posts
      res.render('home', { user: req.session.user, posts, req: req });
    });
  });


// Profile Page
app.get('/profile', requireLogin, (req, res) => {
  const userId = req.session.user.id;

  // Fetch user information
  db.get('SELECT * FROM users WHERE id = ?', [userId], (err, user) => {
    if (err) {
      console.error(err.message);
      return res.status(500).send('Internal Server Error');
    }

    // Fetch associated projects for the logged-in user
    db.all('SELECT * FROM projects WHERE user_id = ?', [userId], (err, userProjects) => {
      if (err) {
        console.error(err.message);
        return res.status(500).send('Internal Server Error');
      }

      // Render the profile page with user information and associated projects
      res.render('profile', { user, projects: userProjects, skills: user.skills });
    });
  });
});

  

// Teams page
app.get('/teams', requireLogin, (req, res) => {
  const userId = req.session.user.id;

  // Fetch user information
  db.get('SELECT * FROM users WHERE id = ?', [userId], (err, user) => {
    if (err) {
      console.error(err.message);
      return res.status(500).send('Internal Server Error');
    }

    // Fetch all teams
    db.all('SELECT * FROM teams', (err, allTeams) => {
      if (err) {
        console.error(err.message);
        return res.status(500).send('Internal Server Error');
      }

      // Fetch teams joined by the user
      db.get('SELECT teams_joined FROM users WHERE id = ?', [userId], (err, userTeams) => {
        if (err) {
          console.error(err.message);
          return res.status(500).send('Internal Server Error');
        }

        console.log('User Teams:', userTeams);

        // Process the teams_joined string into an array of team IDs
        const teamsJoined = userTeams.teams_joined ? userTeams.teams_joined.split(',').map(Number) : [];

        console.log('Teams Joined:', teamsJoined);

        // Render the teams page with the list of all teams and teams joined
        res.render('teams', { user, allTeams, teamsJoined });
      });
    });
  });
});

// Handle Joining a Team:
app.post('/join-team/:teamId', (req, res) => {
  const userId = req.session.user.id;
  const teamId = req.params.teamId;

  // Check if the user is already a member of the team
  db.get('SELECT teams_joined FROM Users WHERE id = ?', [userId], (err, user) => {
    if (err) {
      console.error(err.message);
      return res.status(500).send('Internal Server Error');
    }

    // Process the teams_joined string into an array of team IDs
    const teamsJoined = user.teams_joined ? user.teams_joined.split(',').map(Number) : [];

    // Check if the user is already a member of the team
    if (teamsJoined.includes(parseInt(teamId, 10))) {
      return res.status(400).send('User is already a member of the team');
    }

    // Perform the update in the database to add the team ID to teams_joined
    db.run('UPDATE Users SET teams_joined = COALESCE(teams_joined || \',\', \'\') || ? WHERE id = ?', [teamId, userId], (err) => {
      if (err) {
        console.error(err.message);
        return res.status(500).send('Internal Server Error');
      }

      res.sendStatus(200);
    });
  });
});

// Handle leaving a team
app.post('/leave-team/:teamId', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const teamId = req.params.teamId;

  // Fetch the user's teams_joined from the database
  db.get('SELECT teams_joined FROM users WHERE id = ?', [userId], (err, userTeams) => {
    if (err) {
      console.error(err.message);
      return res.status(500).send('Internal Server Error');
    }

    // Process the teams_joined string into an array of team IDs
    const teamsJoined = userTeams.teams_joined ? userTeams.teams_joined.split(',').map(Number) : [];

    // Check if the user is in the team
    const teamIndex = teamsJoined.indexOf(parseInt(teamId));
    if (teamIndex !== -1) {
      // If the user is in the team, remove the team from the user's teams_joined
      teamsJoined.splice(teamIndex, 1);

      // Update the user's teams_joined in the database
      db.run('UPDATE users SET teams_joined = ? WHERE id = ?', [teamsJoined.join(','), userId], (err) => {
        if (err) {
          console.error(err.message);
          return res.status(500).send('Internal Server Error');
        }

        // Redirect back to the /teams page after leaving the team
        res.redirect('/teams');
      });
    } else {
      // If the user is not in the team, redirect back to the /teams page without modifying anything
      res.redirect('/teams');
    }
  });
});


// Handle edit profile
app.get('/edit-profile', requireLogin, (req, res) => {
  const userId = req.session.user.id;

  // Fetch the latest user details from the database
  db.get('SELECT * FROM users WHERE id = ?', [userId], (err, user) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Render the edit profile page with the latest user details
    res.render('edit-profile', { user });
  });
});

  app.post('/update-profile', requireLogin, (req, res) => {
    const { certs, newPassword, newEmail, newSkills } = req.body;
    const userId = req.session.user.id;
  
    // Check if a new password is provided
    if (newPassword) {
      // Hash and salt the new password
      bcrypt.hash(newPassword, 10, (hashErr, hashedPassword) => {
        if (hashErr) {
          console.error(hashErr.message);
          res.status(500).send('Internal Server Error');
          return;
        }
  
        // Update the user's certifications and password in the database
        db.run('UPDATE users SET certs = ?, password = ?, email = ?, skills = ? WHERE id = ?', [certs, hashedPassword, newEmail, newSkills, userId], (updateErr) => {
          if (updateErr) {
            console.error(updateErr.message);
            res.status(500).send('Internal Server Error');
            return;
          }
  
          // Update the session with the new certifications
          req.session.user.certs = certs;
          req.session.user.email = newEmail;
          req.session.user.skills = newSkills;
  
          // Redirect back to the profile page after updating
          res.redirect('/profile');
        });
      });
    } else {
      // Update the user's certifications, email, and skills without changing the password
      db.run('UPDATE users SET certs = ?, email = ?, skills = ? WHERE id = ?', [certs, newEmail, newSkills, userId], (updateErr) => {
        if (updateErr) {
          console.error(updateErr.message);
          res.status(500).send('Internal Server Error');
          return;
        }
  
        // Update the session with the new certifications
        req.session.user.certs = certs;
        req.session.user.email = newEmail;
        req.session.user.skills = newSkills;
  
        // Redirect back to the profile page after updating
        res.redirect('/profile');
      });
    }
  });
  
  app.get('/new-post', requireLogin, (req, res) => {
    res.render('new-post', { user: req.session.user });
  });

  app.post('/create-post', requireLogin, (req, res) => {
    const { content } = req.body;
  
    // Insert the new post into the database
    db.run('INSERT INTO posts (user_id, content) VALUES (?, ?)', [req.session.user.id, content], (err) => {
      if (err) {
        console.error(err.message);
        res.status(500).send('Internal Server Error');
        return;
      }
  
      // Redirect to the home page after creating the post
      res.redirect('/home');
    });
  });

// Add a route to toggle likes
app.post('/toggle-like/:postId', requireLogin, (req, res) => {
  const postId = req.params.postId;
  const userId = req.session.user.id;

  // Check if the user has already liked the post
  db.get('SELECT * FROM liked_posts WHERE user_id = ? AND post_id = ?', [userId, postId], (err, likedPost) => {
    if (err) {
      console.error(err.message);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }

    if (likedPost) {
      // User has already liked the post, so unlike it
      db.run('DELETE FROM liked_posts WHERE user_id = ? AND post_id = ?', [userId, postId], (err) => {
        if (err) {
          console.error(err.message);
          res.status(500).json({ error: 'Internal Server Error' });
          return;
        }

        // Decrease likes_count in the posts table
        db.run('UPDATE posts SET likes_count = likes_count - 1 WHERE id = ?', [postId], (err) => {
          if (err) {
            console.error(err.message);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
          }

          // Retrieve updated likes_count for the post
          db.get('SELECT likes_count FROM posts WHERE id = ?', [postId], (err, post) => {
            if (err) {
              console.error(err.message);
              res.status(500).json({ error: 'Internal Server Error' });
              return;
            }

            res.json({ likesCount: post.likes_count, liked: false });
          });
        });
      });
    } else {
      // User has not liked the post, so like it
      db.run('INSERT INTO liked_posts (user_id, post_id) VALUES (?, ?)', [userId, postId], (err) => {
        if (err) {
          console.error(err.message);
          res.status(500).json({ error: 'Internal Server Error' });
          return;
        }

        // Increase likes_count in the posts table
        db.run('UPDATE posts SET likes_count = likes_count + 1 WHERE id = ?', [postId], (err) => {
          if (err) {
            console.error(err.message);
            res.status(500).json({ error: 'Internal Server Error' });
            return;
          }

          // Retrieve updated likes_count for the post
          db.get('SELECT likes_count FROM posts WHERE id = ?', [postId], (err, post) => {
            if (err) {
              console.error(err.message);
              res.status(500).json({ error: 'Internal Server Error' });
              return;
            }

            res.json({ likesCount: post.likes_count, liked: true });
          });
        });
      });
    }
  });
});

  
// New-Project Page
app.get('/new-project', requireLogin, (req, res) => {
  // Fetch the list of users with role 'user'
  db.all('SELECT id, username FROM users WHERE role = ?', ['user'], (err, users) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Render the new project form with the list of users
    res.render('new-project', { user: req.session.user, users: users });
  });
});

// Handle form submission to create a new project
app.post('/create-project', requireLogin, upload.single('image'), (req, res) => {
  const { name, title, description, creator, collaborators, tasks, start_date, end_date } = req.body;

  // Get the file path if an image was uploaded
  const imagePath = req.file ? req.file.path : null;

  // Insert the new project into the database
  db.run('INSERT INTO projects (name, title, description, creator, collaborators, tasks, start_date, end_date, user_id, project_picture) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    [name, title, description, creator, collaborators, tasks, start_date, end_date, req.session.user.id, imagePath],
    (err) => {
      if (err) {
        console.error(err.message);
        res.status(500).send('Internal Server Error');
        return;
      }

      // Redirect to the projects page after creating the project
      res.redirect('/projects');
    });
});

// Route to delete a post
app.post('/delete-post/:postId', isAdmin, (req, res) => {
  const postId = parseInt(req.params.postId);

  // Execute the query
  db.run('DELETE FROM posts WHERE id = ?', [postId], (err) => {
    if (err) {
      console.error(err.message);
      res.json({ success: false, error: 'Error deleting post' });
    } else {
      res.json({ success: true });
    }
  });
});

// Handle project editing
app.get('/edit-project/:projectId', requireLogin, (req, res) => {
  const userId = req.session.user.id;
  const projectId = req.params.projectId;

  // Fetch the project details from the database
  db.get('SELECT * FROM projects WHERE id = ? AND user_id = ?', [projectId, userId], (err, project) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    if (!project) {
      // The project doesn't exist or doesn't belong to the user
      res.status(404).send('Project not found');
      return;
    }

    // Render the edit-project page with the project details
    res.render('edit-project', { user: req.session.user, project });
  });
});

// Handle form submission to update a project
app.post('/update-project/:projectId', requireLogin, (req, res) => {
  const projectId = req.params.projectId;
  const userId = req.session.user.id;
  const { name, title, description, collaborators, tasks, start_date, end_date, status } = req.body;

  // Verify if the user is the creator of the project
  db.get('SELECT * FROM projects WHERE id = ? AND user_id = ?', [projectId, userId], (err, project) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    if (!project) {
      // If the project doesn't belong to the user, return a forbidden status
      res.status(403).send('Forbidden');
      return;
    }

    // Update the project details in the database
    db.run('UPDATE projects SET name = ?, title = ?, description = ?, collaborators = ?, tasks = ?, start_date = ?, end_date = ?, status = ? WHERE id = ?',
      [name, title, description, collaborators, tasks, start_date, end_date, status, projectId],
      (updateErr) => {
        if (updateErr) {
          console.error(updateErr.message);
          res.status(500).send('Internal Server Error');
          return;
        }

        // Redirect to the projects page after updating the project
        res.redirect('/projects');
      });
  });
});

// Handle the search query
app.get('/search', requireLogin, (req, res) => {
  const { query } = req.query;

  // Perform a search based on the query (customize this query as needed)
  db.all('SELECT posts.*, users.username, users.profile_picture FROM posts JOIN users ON posts.user_id = users.id WHERE content LIKE ?', [`%${query}%`], (err, searchResults) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Render the search results page with the query and searchResults
    res.render('search', { user: req.session.user, query, searchResults });
  });
});

// Handle the search form submission
app.post('/search', requireLogin, (req, res) => {
  const user = req.session.user;
  const query = req.body.query;

  // Perform a search based on the query (you can customize this query)
  db.all('SELECT * FROM posts WHERE content LIKE ?', [`%${query}%`], (err, searchResults) => {
    if (err) {
      console.error(err.message);
      res.status(500).send('Internal Server Error');
      return;
    }

    // Render the search results
    res.render('search', { user, searchResults, query });
  });
});

// Start the server
app.listen(port, () => {
  //Here the server starts on localhost, port 3000
  console.log(`Server is running at http://localhost:${port}`);
});
